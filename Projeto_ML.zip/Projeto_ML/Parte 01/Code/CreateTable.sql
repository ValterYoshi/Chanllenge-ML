USE [master]
GO

/****** Object:  Database [DatabaseML]    Script Date: 27/02/2024 14:37:59 ******/
CREATE DATABASE [DatabaseML]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'DatabaseML', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL16.MSSQLSERVER\MSSQL\DATA\DatabaseML.mdf' , SIZE = 8192KB , MAXSIZE = UNLIMITED, FILEGROWTH = 65536KB )
 LOG ON 
( NAME = N'DatabaseML_log', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL16.MSSQLSERVER\MSSQL\DATA\DatabaseML_log.ldf' , SIZE = 8192KB , MAXSIZE = 2048GB , FILEGROWTH = 65536KB )
 WITH CATALOG_COLLATION = DATABASE_DEFAULT, LEDGER = OFF
GO

USE DatabaseML


IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='TbCustomer' and xtype='U')
   CREATE TABLE TbCustomer(
   customerId int IDENTITY(1,1) PRIMARY KEY, 
   name VARCHAR(255) NULL,
   email VARCHAR(255) NULL,
   nickname VARCHAR(100) NULL,
   sex CHAR(1) NULL,
   address VARCHAR(45) NULL,
   birthDate DATE NULL,
   phone INT NULL
    )
GO

IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='TbOrder' and xtype='U')
   CREATE TABLE TbOrder(
   orderId int IDENTITY(1,1) PRIMARY KEY, 
   customerId INT NOT NULL,
   orderCloseDate Date NOT NULL,
   INDEX idx_tbOrder_Customer_idx (customerId ASC),
   FOREIGN KEY (customerid) REFERENCES TbCustomer(customerId)
    )
GO

IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='TbOrderItem' and xtype='U')
   CREATE TABLE TbOrderItem(
   orderItemId int IDENTITY(1,1) PRIMARY KEY, 
   orderId INT NOT NULL,
   itemId INT NOT NULL,
   itemQuantity INT NOT NULL,
   price DECIMAL (18,2)  NOT NULL,
   itemPay DECIMAL (18,2)   NULL
   INDEX idx_tbOrderItem_orderID_idx (orderId ASC,itemId ASC),
   FOREIGN KEY (orderid) REFERENCES TbOrder(orderId),
   FOREIGN KEY (ItemId) REFERENCES TbItem(itemId)
    )
GO


IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='TbCategory' and xtype='U')
   CREATE TABLE TbCategory(
   categoryId INT IDENTITY(1,1) PRIMARY KEY, 
   descCategory VARCHAR (150) NOT NULL,
   pathCategory VARCHAR (255) NOT NULL
    )
GO

IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='TbBrand' and xtype='U')
   CREATE TABLE TbBrand(
   brandId INT IDENTITY(1,1) PRIMARY KEY, 
   descBrand VARCHAR (60) NOT NULL
    )
GO

IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='TbItem' and xtype='U')
   CREATE TABLE TbItem(
   itemId int IDENTITY(1,1) PRIMARY KEY, 
   categoryId INT NOT NULL,
   brandId INT NOT NULL,
   descItem varchar(255) NOT NULL,
   dischargeDate DATE NOT NULL,
   statusItem VARCHAR(50) NOT NULL,
   price DECIMAL(18,2) NOT NULL,
   availableQuantity INT NOT NULL,
   vendorId INT NOT NULL,
   INDEX idx_TbItem_categoryId_1_idx (categoryId ASC),
   INDEX idx_TbItem_brandIS_idx (brandId ASC),
   FOREIGN KEY (categoryId) REFERENCES TbCategory(categoryId),
   FOREIGN KEY (brandId) REFERENCES TbBrand(brandId),
   FOREIGN KEY (vendorId) REFERENCES TbVendor(vendorId)
    )
GO 
 


IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='TbItemHist' and xtype='U')
   CREATE TABLE TbItemDailyHist(
   itemHistId int IDENTITY(1,1) PRIMARY KEY, 
   itemId INT NOT NULL,
   price DECIMAL(18,2) NOT NULL,
   availableQuantity INT NOT NULL,
   vendorId INT NOT NULL,
   creationDate Date NULL DEFAULT (getdate()),
   INDEX idx_TbItemHist_itemId (itemId ASC),
   CONSTRAINT idxu_TbItemHist_itemId UNIQUE (itemId, creationDate ),
   FOREIGN KEY (itemId) REFERENCES TbItem(itemId)
    )
GO


IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='TbVendor' and xtype='U')
   CREATE TABLE TbVendor(
   vendorId int IDENTITY(1,1) PRIMARY KEY, 
   name VARCHAR(255) NULL,
   email VARCHAR(255) NULL,
   nickname VARCHAR(100) NULL,
   sex CHAR(1) NULL,
   address VARCHAR(45) NULL,
   birthDate DATE NULL,
   phone INT NULL,
   INDEX idx_TbVendor_itemId (itemId ASC)

    )
GO
