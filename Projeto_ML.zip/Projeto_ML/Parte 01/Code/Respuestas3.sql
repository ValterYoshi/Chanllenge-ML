﻿USE DatabaseML
GO

DECLARE @dt_atual date;
set @dt_atual = getdate();

/*
1. Listar los usuarios que cumplan a�os el d�a de hoy cuya cantidad de ventas
realizadas en enero 2020 sea superior a 1500.
*/

--update TbCustomer 
--set birthDate = DATEADD(MONTH, -24,@dt_atual)
--where customerId = 5;

select 		c.customerId
			,email
			,name
			,nickname
from 		TbCustomer as c
join 		TbOrder as o
on			c.customerId = o.customerId
where 		FORMAT(birthDate, 'd MMM') =  FORMAT(@dt_atual, 'd MMM')
and 		
o.orderCloseDate between '2020-01-01' and '2020-01-31'
group by 	c.customerId
			,email
			,name
			,nickname
having 		count(orderId) > 1500



-----------------------


-- ----------------------------------------------------------------------------------------------- --
/*
Por cada mes del 2020, se solicita el top 5 de usuarios que mas vendieron($) en la
categor�a Celulares. Se requiere el mes y ano de analisis, nombre y apellido del
vendedor, cantidad de ventas realizadas, cantidad de productos vendidos y el monto
total transaccionado.
 */

select 		vendorId
			,name
			,nickname
			,mes_ano
			,ctdOrder as 'cantidad de ventas realizadas'
			,sumQt as 'cantidad de productos vendidos'
			,sumMonto as 'monto total transaccionado'
from 		(select 	FORMAT(orderCloseDate, 'MM-yyyy') as mes_ano
						,c.vendorId
						,c.name
						,c.nickname
						,count(oi.orderId) as ctdOrder
						,sum(oi.itemQuantity) as sumQt
						,sum(oi.itemPay) as sumMonto
						,row_number () over (partition by c.vendorId order by sum(oi.itempay) desc) as rank_id
			from 		TbVendor as c					join 			TbItem as i 
			on 			i.vendorId = c.vendorId			join		TbCategory as ca
			on 			ca.categoryId = i.categoryId	join		TbOrderItem as oi
			on			oi.itemId = i.itemId			join			TbOrder as o
			on			o.orderId = oi.orderId
			where 		o.orderCloseDate between '2020-01-01' and '2020-12-31'
			and 		ca.descCategory = 'Mobile'
			group by 	FORMAT(orderCloseDate, 'MM-yyyy')
						,c.vendorId
						,c.name
						,c.nickname) as cr
where 		rank_id <= 5
order by mes_ano
-- ----------------------------------------------------------------------------------------------- --

/*
Se solicita poblar una nueva tabla con el precio y estado de los �tems a fin del d�a.
Tener en cuenta que debe ser reprocesable. Vale resaltar que en la tabla Item,
vamos a tener �nicamente el �ltimo estado informado por la PK definida. (Se puede
resolver a trav�s de StoredProcedure)
*/

-- =======================================================
-- Create Stored Procedure Template for Azure SQL Database
-- =======================================================
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author: Valter Vieira
-- Create Date: 01/03/2024
-- Description: Se solicita poblar una nueva tabla con el precio y estado de los �tems a fin del d�a.
---Tener en cuenta que debe ser reprocesable. Vale resaltar que en la tabla Item,
---vamos a tener �nicamente el �ltimo estado informado por la PK definida. (Se puede
---resolver a trav�s de StoredProcedure)
-- =============================================

 CREATE OR ALTER PROCEDURE uspUpdateItem
@creation_date as date
AS   
SET NOCOUNT ON;
BEGIN TRY
 
			MERGE
			INTO TbItemDailyHist AS target
			USING (select 	i.itemId 
					,i.price
					,i.statusItem
					,i.availableQuantity
					,vendorId
					,@creation_date as creationDate
 					---,creation_date
			from 	tbItem as i) as source(itemId,price,statusItem,availableQuantity,vendorId,creationDate)
			ON (target.itemId = source.itemId)
			WHEN MATCHED
			  THEN UPDATE
				  SET	target.price = source.price,
						target.availableQuantity = source.availableQuantity,
						target.statusItem = source.statusItem

			WHEN NOT MATCHED
			  THEN INSERT (itemId, price, statusItem,availableQuantity ,vendorId,creationDate)
			  Values (source.itemId, source.price, source.statusItem,source.availableQuantity, source.vendorId,source.creationDate);
			  
	END TRY

BEGIN CATCH
  -- Determine if an error occurred.
  IF @@TRANCOUNT > 0
    ROLLBACK TRANSACTION

  -- Return the error information.
  DECLARE @ErrorMessage NVARCHAR(4000), @ErrorSeverity INT;
  SELECT @ErrorMessage = ERROR_MESSAGE(),@ErrorSeverity = ERROR_SEVERITY();
  RAISERROR(@ErrorMessage, @ErrorSeverity, 1)
  end catch



DECLARE @dt_atual date;
set @dt_atual = getdate();

EXEC uspUpdateItem @dt_atual


select * from [dbo].[TbItemDailyHist]
select * from [dbo].[TbItem]

update TbItem 
set price = 5500
where itemId = 7

