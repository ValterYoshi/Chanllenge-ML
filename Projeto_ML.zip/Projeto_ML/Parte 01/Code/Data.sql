USE [DatabaseML]
GO

INSERT INTO [dbo].[TbCustomer]
           ([name]
           ,[email]
           ,[nickname]
           ,[sex]
           ,[address]
           ,[birthDate]
           )
     VALUES
			('Valter','valtedvf@gmail.com','Valter','M','Rua das Grumixamas','1985-09-30'),
			('Priscila','priscilavieira@gmail.com','Pri','F','Rua das Grumixamas','1987-04-16'),
			('Liam Kojiro','LiamKojiro@gmail.com','Liam','M','Rua das Grumixamas','2021-02-02'),
			('Wendy','wendylc@gmail.com','Wendyzinha','F','Rua das Perobas','1986-11-23'),
			('Robson','robsonmiorini@gmail.com','Robsan','M','Rua andarai','1984-04-16'),
			('Beatriz','biagomes@gmail.com','Bia','F','Rua Cruz Das Almas','1952-03-16'),
			('Cloud','CloudStrike@gmail.com','Loirinho','M','Rua Junon','1985-09-30')
GO

---##########################################################################################################################
  ----#######################################################
  ---- Atualiza os Vendedores dos produtos cadastrados ------ 
  ----########################################################

INSERT INTO [dbo].[TbOrder]
           ([customerId]
           ,[orderCloseDate])
     VALUES
			 (1,'2020-02-01')
			,(1,'2020-03-01')
			,(2,'2020-01-01')
			,(3,'2020-03-01')
			,(4,'2020-04-01')
			,(4,'2020-01-01')
			,(4,'2020-05-01')
			,(4,'2020-01-01')
			,(4,'2020-07-01')
			,(5,'2020-08-01')
			,(5,'2020-01-01')
			,(5,'2020-01-01')
			,(5,'2020-09-01')
			,(5,'2020-08-01')
			,(6,'2020-08-01')
			,(6,'2020-03-01')
			,(1,'2020-10-01')
			,(1,'2020-01-01')
			,(1,'2020-07-01')
			,(1,'2020-10-01')
			,(3,'2020-02-01')
			,(4,'2020-02-01')
			,(5,'2020-06-01')
			,(6,'2020-10-01')
			,(1,'2020-06-01')
			,(1,'2020-07-01')
			,(3,'2020-09-01')
			,(3,'2020-07-01')
			,(5,'2020-04-01')
			,(4,'2020-04-01')
			,(3,'2020-06-01')
			,(2,'2020-05-01')
			,(2,'2020-06-01')
			,(2,'2020-04-01')
			,(3,'2020-05-01')
			,(6,'2020-12-01')
			,(1,'2020-12-01')
			,(1,'2020-12-01')
			,(3,'2020-12-01')
			,(3,'2020-12-01')
			,(5,'2020-10-01')
			,(4,'2020-11-01')
			,(3,'2020-11-01')
			,(2,'2020-11-01')
			,(2,'2020-11-01')
			,(2,'2020-11-01')
			,(3,'2020-10-01')
GO

---################################################################################################################
  ----#######################################################
  ---- Atualiza os Vendedores dos produtos cadastrados ------ 
  ----########################################################

INSERT INTO [dbo].[TbCategory]
           ([descCategory]
           ,[pathCategory])
     VALUES
		     ('Mobile','Technology/Mobile+and+Phone/Mobile+and+Smartphones')
			,('Television','Technology/TV')
			,('Home','Home/Furniture')
GO

----##############################################################################################################
  ----#######################################################
  ---- Atualiza os Vendedores dos produtos cadastrados ------ 
  ----########################################################

USE [DatabaseML]
GO

INSERT INTO [dbo].[TbBrand]
           ([descBrand])
     VALUES
           ('Apple' ),
		   ('Samsung'),
		   ('Xiaomi'),
		   ('LG'),   
		   ('Castor'),
		   ('Emma')


GO

truncate table  [dbo].[TbBrand]
---##########################################################################################
  ----#######################################################
  ---- Atualiza os Vendedores dos produtos cadastrados ------ 
  ----########################################################
USE [DatabaseML]
GO

INSERT INTO [dbo].[TbItem]
           ([categoryId]
           ,[brandId]
           ,[descItem]
           ,[dischargeDate]
           ,[statusItem]
           ,[price]
           ,[availableQuantity]
           ,[vendorId])

     VALUES
			('1','1','Iphone1','2999-01-01','availability',10000,10,1),
			('1','1','Iphone1','2999-01-01','availability',12000,5,2),
			('1','2','Galaxy S24','2999-01-01','availability',8500,3,1),
			('1','2','Galaxy S22','2999-01-01','availability',6500,5,2),
			('1','3','Red Note 12','2999-01-01','availability',3000,10,3),
			('1','3','Redmi 11','2999-01-01','availability',5000,3,5),
			('1','4','Televis�o 50 Polegas','2999-01-01','availability',4500,7,4)
			

  ----#######################################################
  ---- Atualiza os Vendedores dos produtos cadastrados ------ 
  ----########################################################
----#################################################################################
INSERT INTO [dbo].[TbOrderItem]
           ([orderId]
           ,[itemId]
           ,[itemQuantity]
           ,[price]
           ,[itemPay])
     VALUES
			(8,1,1,0,0),
			(8,2,1,0,0),
			(9,1,2,0,0),
			(10,1,1,0,0),
			(11,1,2,0,0),
			(12,1,1,0,0),
			(13,1,1,0,0),
			(14,1,1,0,0),
			(15,1,1,0,0),	
			(16,1,1,0,0),
			(17,1,2,0,0),
			(18,1,2,0,0),
			(19,2,2,0,0),
			(20,2,1,0,0),
			(21,2,3,0,0),
			(22,2,1,0,0),
			(23,2,3,0,0),
			(24,2,1,0,0),
			(25,2,1,0,0),
			(26,2,1,0,0),
			(27,2,2,0,0),
			(28,2,2,0,0),
			(29,4,2,0,0),
			(30,4,2,0,0),
			(31,4,2,0,0),
			(32,4,2,0,0),
			(33,3,1,0,0),
			(34,3,3,0,0),
			(35,3,3,0,0),
			(36,3,3,0,0),
			(37,3,1,0,0),
			(38,5,1,0,0),
			(39,5,1,0,0),
			(40,5,1,0,0),
			(41,5,1,0,0),
			(42,6,1,0,0),
			(43,6,1,0,0),
			(44,6,1,0,0),
			(45,6,1,0,0),
			(46,6,1,0,0),
			(47,6,1,0,0),
			(48,6,1,0,0),
			(49,6,1,0,0),
			(50,6,1,0,0),
			(51,6,1,0,0),
			(52,4,1,0,0),
			(53,4,1,0,0),
			(54,4,1,0,0),
			(55,4,1,0,0)

GO

----#######################################################
---- Atualiza os Vendedores dos produtos cadastrados ------ 
----########################################################

UPDATE [dbo].[TbOrderItem]
   SET price = i.price
   from TbOrderItem o Inner Join TbItem i ON o.itemId = i.itemId
GO

----#######################################################
---- Atualiza os Vendedores dos produtos cadastrados ------ 
----########################################################

UPDATE [dbo].[TbOrderItem]
   SET itemPay = price * itemQuantity
GO

  ----#######################################################
  ---- Atualiza os Vendedores dos produtos cadastrados ------ 
  ----########################################################

INSERT INTO [dbo].[TbVendor]
           ([name]
           ,[email]
           ,[nickname]
           ,[sex]
           ,[address]
           ,[birthDate]
           ,[phone]
           ,[itemId])
     VALUES
	 ('Jo�o Madeira', 'joao@gmail.com','Jonny','M','Rua Santo','1995-10-02','991064545'),
	 ('Maria Jose', 'joao@gmail.com','Jonny','M','Rua Santo','1995-10-02','991064545'),
	 ('Bonifacia', 'joao@gmail.com','Jonny','M','Rua Santo','1995-10-02','991064545'),
	 ('Pedro Santos', 'joao@gmail.com','Jonny','M','Rua Santo','1995-10-02','991064545'),
	 ('Joao das Couves', 'joao@gmail.com','Jonny','M','Rua Santo','1995-10-02','991064545'),
	 ('Maria Candida', 'joao@gmail.com','Jonny','M','Rua Santo','1995-10-02','991064545'),
	 ('Fred  Eira', 'joao@gmail.com','Fered','M','Rua Santo','1995-10-02','991064545'),
	 ('Hyju Madeira', 'joao@gmail.com','Hy','M','Rua Santo','1995-10-02','991064545')

GO




  ----#######################################################
  ---- Atualiza os Vendedores dos produtos na Tabela OrderItem ------ 
  ----########################################################

  Update [TbOrderItem]
  set vendorId = v.vendorId, vendorName = v.name
  From TbOrderItem i inner Join [dbo].[TbVendor] v on v.itemId = i.itemId

  ----#######################################################
  ---- Atualiza os Vendedores dos produtos cadastrados ------ 
  ----########################################################

 Update TbItem
  set  vendorId = v.vendorId
  From TbItem i inner Join [dbo].[TbVendor] v on v.itemId = i.itemId

