import requests
import pandas as pd

def busca_dados(pesquisa, limite):
    ''' #######################################################################
        Inicia a busca de acordo com a pesquisa e limite de registros informados
        ######################################################################### '''

    global df_retorno
    resultado = pd.DataFrame()
    for busca in pesquisa:
        print('Iniciando a busca da pesquisa {}....'.format(busca), end='')
        uri_busca = 'https://api.mercadolibre.com/sites/MLA/search?q={}&limit={}#json'.format(busca, limite)
        busca_dado = requests.get(uri_busca)
        resultado_dado = busca_dado.json()

        for idx in range(len(resultado_dado.get('results'))):
            item_id = resultado_dado.get('results')[idx].get('id')
            uri = 'https://api.mercadolibre.com/items/{}'.format(item_id)
            busca_item = requests.get(uri)
            resultado_busca = busca_item.json()
            df_retorno = pd.json_normalize(resultado_busca)
            df_retorno['pesquisa'] = busca
            try:
                resultado = resultado._append(df_retorno)
            except:
                resultado = df_retorno

        print('Concluida.')
    return resultado

def main():
    print('insere retornos de busca.....', end='')
    pesquisa = ['chromecast', 'Google Home', 'Apple TV', 'Amazon Fire TV']
    '''pesquisa = ['chromecast']'''
    limite = '50'
    nome_arquivo = 'retorno_api .txt'
    print('Concluido')
    print('Realizando a busca.....')
    df_retorno = busca_dados(pesquisa, limite)
    print('Busca concluida.')

    print('Salvando arquivo {} '.format(nome_arquivo), end='')
    df_retorno.to_csv(nome_arquivo, index=False, sep=',')
    print('Arquivo salvo.')


main()

print('Processo finalizado')
